/*********************************************************************************
*  WEB700 – Assignment 03
*  I declare that this assignment is my own work in accordance with Seneca  Academic Policy.  No part 
*  of this assignment has been copied manually or electronically from any other source 
*  (including 3rd party web sites) or distributed to other students.
* 
*  Name: __Anjali Ghai__ Student ID: __179544218__ Date: __19 Feb 2023__
*
********************************************************************************/ 
var HTTP_PORT = process.env.PORT || 8080;
var express = require("express");
var app = express();

// setup a 'route' to listen on the default url path
app.get("/", (req, res) => {
    res.send("Hello World!");
});

// setup http server to listen on HTTP_PORT
app.listen(HTTP_PORT, ()=>{console.log("server listening on port: " + HTTP_PORT)});

const express = require("express");
const path = require("path");
const collegeData = require("C:\BTT sem2\WEB\A3\modules\collegeData.js");

const app = express();

app.use(express.static(path.join(__dirname, "public")));

app.get("/students", (req, res) => {
  collegeData.getAllStudents().then((students) => {
    if (req.query.course) {
      students = collegeData.getStudentsByCourse(students, req.query.course);
    }
    if (students.length === 0) {
      res.status(404).json({ message: "no results" });
    } else {
      res.json(students);
    }
  }).catch((err) => {
    console.error(err);
    res.status(500).json({ message: "internal server error" });
  });
});

app.get("/tas", (req, res) => {
  collegeData.getTAs().then((tas) => {
    if (tas.length === 0) {
      res.status(404).json({ message: "no results" });
    } else {
      res.json(tas);
    }
  }).catch((err) => {
    console.error(err);
    res.status(500).json({ message: "internal server error" });
  });
});

app.get("/courses", (req, res) => {
  collegeData.getCourses().then((courses) => {
    if (courses.length === 0) {
      res.status(404).json({ message: "no results" });
    } else {
      res.json(courses);
    }
  }).catch((err) => {
    console.error(err);
    res.status(500).json({ message: "internal server error" });
  });
});

app.get("/student/:num", (req, res) => {
  collegeData.getStudentByNum(req.params.num).then((student) => {
    if (!student) {
      res.status(404).json({ message: "no results" });
    } else {
      res.json(student);
    }
  }).catch((err) => {
    console.error(err);
    res.status(500).json({ message: "internal server error" });
  });
});

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "views", "home.html"));
});

app.get("/about", (req, res) => {
  res.sendFile(path.join(__dirname, "views", "about.html"));
});

app.get("/htmlDemo", (req, res) => {
  res.sendFile(path.join(__dirname, "views", "htmlDemo.html"));
});

app.use((req, res) => {
  res.status(404).send("Page Not Found");
});

collegeData.initialize().then(() => {
  app.listen(8080, () => {
    console.log("Server started on port 8080");
  });
}).catch((err) => {
  console.error(err);
});
